﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace Paper_Down_Under
{
    class PlayerHUD
    {
        private int hP { get; set; }
        private int def { get; set; }
        private int acc { get; set; }
        private int atk { get; set; }
        private int spd { get; set; }
        private int gold { get; set; }
        private int maxHP { get; set; }
        private int maxTP { get; set; }
        private int tP { get; set; }
        Texture2D hpBarText;
        Texture2D tpBarText;
        Texture2D gBarText;
        Rectangle hpBarRect;
        Rectangle tpBarRect;
        Texture2D hpIconText;
        Texture2D tpIconText;
        Texture2D gIconText;
        Rectangle hpIconRect;
        Rectangle tpIconRect;
        Rectangle gIconRect;
        SpriteFont sF;

        public PlayerHUD(int health, int defense, int accuracy, int attack, int speed, int tension)
        {
            hP = health;
            maxHP = hP;
            def = defense;
            acc = accuracy;
            atk = attack;
            spd = speed;
            tP = tension;
            maxTP = tP;
            gold = 0;
        }

        public void LC(SpriteFont spriteFont, Texture2D healthBar, Texture2D tensionBar, Texture2D healthIcon, Texture2D tensionIcon, Texture2D coinIcon)
        {
            sF = spriteFont;
            hpBarText = healthBar;
            tpBarText = tensionBar;
            hpBarRect = new Rectangle(50, 50, 300, 150);
            tpBarRect = new Rectangle(390, 50, 300, 150);
            hpIconText = healthIcon;
            tpIconText = tensionIcon;
            gIconText = coinIcon;
            hpIconRect = new Rectangle(0, 70, 140, 80);
            tpIconRect = new Rectangle(370, 70, 80, 80);
            gIconRect = new Rectangle(1000, 70, 70, 70);
        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            KeyboardState kB = Keyboard.GetState();
            spriteBatch.Draw(hpBarText, hpBarRect, Color.White);
            spriteBatch.Draw(tpBarText, tpBarRect, Color.White);
            spriteBatch.Draw(hpIconText, hpIconRect, Color.White);
            spriteBatch.Draw(tpIconText, tpIconRect, Color.White);
            spriteBatch.Draw(gIconText, gIconRect, Color.White);
            spriteBatch.DrawString(sF, hP + "/" + maxHP, new Vector2(110, 90), Color.White);
            spriteBatch.DrawString(sF, tP + "/" + maxTP, new Vector2(450, 90), Color.White);
            spriteBatch.DrawString(sF, "x" + gold, new Vector2(1080, 80) , Color.White);
            //Below is for the extra stats that aren't going to be drawn
            if (kB.IsKeyDown(Keys.Tab))
            {
                spriteBatch.DrawString(sF, "Attack: " + atk, new Vector2(40, 200), Color.White);
                spriteBatch.DrawString(sF, "Defense: " + def, new Vector2(40, 300), Color.White);
                spriteBatch.DrawString(sF, "Accuracy: " + acc + "%", new Vector2(40, 400), Color.White);
                spriteBatch.DrawString(sF, "Speed: " + spd, new Vector2(40, 500), Color.White);
            }

        }
    }
}
