﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace Paper_Down_Under
{
    class PlayerHUD
    {
        private int hP;
        private int def;
        private int acc;
        private int atk;
        private int gold;
        private int maxHP;
        private int maxTP;
        private int tP;
         
        public PlayerHUD(int health, int defense, int accuracy, int attack, int tension)
        {
            hP = health;
            maxHP = hP;
            def = defense;
            acc = accuracy;
            atk = attack;
            tP = tension;
            maxTP = tP;
            gold = 0;
        }
        public void LoadContent(Texture2D healthBar, Texture2D tensionBar, Texture2D goldBar, Texture2D healthIcon, Texture2D tensionIcon, Texture2D coinIcon)
        {

        }
        public void setHP(int health)
        {
            hP = health;

        }
        public int getHP()
        {
            return hP;
        }
        public void setMaxHP(int health)
        {
            maxHP = health;

        }
        public int getMaxHP()
        {
            return maxHP;
        }
        public void setDef(int defense)
        {
            def = defense;

        }
        public int getDef()
        {
            return def;
        }
        public void setAcc(int accuracy)
        {
            acc = accuracy;

        }
        public int getAcc()
        {
            return acc;
        }
        public void setGold(int g)
        {
            gold = g;

        }
        public int getGold()
        {
            return gold;
        }
    }
}
