﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Paper_Down_Under
{

    class Enemy : GameObject
    {
        public enum Status
        {
            Poisoned,
            Burned,
            Paralyzed,
            Cursed
        }

        public enum Movement
        {
            Fly_Wander,
            Follow
        }

        private int hP { get; set; }
        private int def { get; set; }
        private int acc { get; set; }
        private int atk { get; set; }
        private string name { get; set; }
        private int gold { get; set; }
        private Movement movement { get; set; }
        private Movement movementFar { get; set; }
        private Movement movementClose { get; set; }

        private Status status;
        private Random random;
        private int xTimer, yTimer;
        private int maxXTimer, maxYTimer;
        private int proximity;
        private Vector2 baseVel;

        //sX = pixels horizontally for each sprite in the sheet
        //sY = height of spritesheet
        //count = # of images in spritesheet
        public Enemy(int h, int d, int ac, int at, int g, string n, Animation _idleAnim, Rectangle _loc, Camera _camera, Movement moFar, Movement moClo, int pro, Vector2 bv, Random ran) : base(_idleAnim, _loc, _camera)
        {
            hP = h;
            def = d;
            acc = ac;
            atk = at;
            name = n;
            gold = g;
            movement = moFar;
            movementFar = moFar;
            movementClose = moClo;
            proximity = pro;
            baseVel = bv;
            random = ran;
            if (movement == Movement.Fly_Wander)
            {
                if (random.Next(2) == 0)
                {
                    vel.X = 1f;
                }
                else
                {
                    vel.X = -1f;
                }

                if (random.Next(2) == 0)
                {
                    vel.Y = 1f;
                }
                else
                {
                    vel.Y = -1f;
                }

                maxXTimer = random.Next(250, 500);
                maxYTimer = random.Next(250, 500);
                xTimer = 0;
                yTimer = 0;
            }
        }

        //poison, burn, etc.
        public void setStatus(Status _status, int dmg, int turns)
        {
            status = _status;
        }

        //when player attacks the enemy
        public int damaged(int dmg)
        {
            if (dmg <= def)
            {
                return 0;
            }
            hP = hP - (dmg - def);
            return (dmg - def);
        }

        public void move(Room curr, Player player)
        {
            Vector2 displacement = new Vector2(loc.Center.X - player._loc.Center.X, loc.Center.Y - player._loc.Center.Y);
            if (displacement.X == 0)
            {
                displacement.X = .1f;
            }
            if (displacement.Y == 0)
            {
                displacement.Y = .1f;
            }
            float distance = (float)Math.Abs(Math.Sqrt(displacement.X * displacement.X + displacement.Y * displacement.Y));
            if (distance <= proximity)
            {
                movement = movementClose;
            }
            else
            {
                movement = movementFar;
            }
            Console.WriteLine(vel);
            displacement.Normalize();

            if (movement == Movement.Fly_Wander)
            {
                if (loc.X + camera.loc.X <= 0 && vel.X < 0)
                {
                    xTimer = 0;
                    vel.X = -vel.X;
                    maxXTimer = random.Next(250, 500);
                }
                if (loc.X + camera.loc.X >= curr.tileMap[0].Length * Game1.TileLength && vel.X > 0)
                {
                    xTimer = 0;
                    vel.X = -vel.X;
                    maxXTimer = random.Next(250, 500);
                }
                if (loc.Y + camera.loc.Y >= curr.tileMap.Length * Game1.TileLength && vel.Y > 0)
                {
                    yTimer = 0;
                    vel.Y = -vel.Y;
                    maxYTimer = random.Next(250, 500);
                }
                if (loc.Y + camera.loc.Y <= 0 && vel.Y < 0)
                {
                    yTimer = 0;
                    vel.Y = -vel.Y;
                    maxYTimer = random.Next(250, 500);
                }

                xTimer++;
                yTimer++;
                if (xTimer >= maxXTimer)
                {
                    xTimer = 0;
                    if (vel.X < 0)
                    {
                        vel.X = baseVel.X;
                    }
                    else
                    {
                        vel.X = -baseVel.X;
                    }
                    maxXTimer = random.Next(250, 500);
                }
                if (yTimer >= maxYTimer)
                {
                    yTimer = 0;
                    if (vel.Y < 0)
                    {
                        vel.Y = baseVel.Y;
                    }
                    else
                    {
                        vel.Y = -baseVel.Y;
                    }
                    maxYTimer = random.Next(250, 500);
                }
            }
            else if (movement == Movement.Follow)
            {
                vel.X = -displacement.X * baseVel.X * 2;
                vel.Y = -displacement.Y * baseVel.Y * 2;
            }
        }

        //Below comes after Player Class is made
        //public string offense(int dmg, Player player)
        //{
        //    int attack = player.damaged(dmg);
        //    string ret = name + " dealt " + attack + " damage to you!";

        //}
        public Boolean isAlive()
        {
            if (hP <= 0)
            {
                return false;
            }
            return true;
        }
    }
}