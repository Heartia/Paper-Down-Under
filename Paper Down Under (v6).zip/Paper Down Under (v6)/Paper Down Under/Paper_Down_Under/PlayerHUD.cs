﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace Paper_Down_Under
{
    class PlayerHUD
    {
        private int hP { get; set; }
        private int def { get; set; }
        private int acc { get; set; }
        private int atk { get; set; }
        private int gold { get; set; }
        private int maxHP { get; set; }
        private int maxTP { get; set; }
        private int tP { get; set; }

        public PlayerHUD(int health, int defense, int accuracy, int attack, int tension)
        {
            hP = health;
            maxHP = hP;
            def = defense;
            acc = accuracy;
            atk = attack;
            tP = tension;
            maxTP = tP;
            gold = 0;
        }

        public void LoadContent(Texture2D healthBar, Texture2D tensionBar, Texture2D goldBar, Texture2D healthIcon, Texture2D tensionIcon, Texture2D coinIcon)
        {

        }
    }
}
