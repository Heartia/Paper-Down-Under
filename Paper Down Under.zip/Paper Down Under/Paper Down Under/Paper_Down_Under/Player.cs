﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace Paper_Down_Under
{
    class Player : GameObject
    {
        private Vector2 baseVel;
        private Vector2 acceleration;
        private KeyboardState kb;
        private Boolean isRight;
        private Animation walkAnim;

        private const float VelStop = 1.5f;

        public Player(Animation _idleAnim, Animation _walkAnim, Rectangle _loc, Camera _camera, Vector2 _baseVel, Vector2 _acceleration) : base(_idleAnim, _loc, _camera)
        {
            baseVel = _baseVel;
            acceleration = _acceleration;
            kb = Keyboard.GetState();
            walkAnim = _walkAnim;
        }

        public void update(GameTime gameTime, Room curr)
        {
            kb = Keyboard.GetState();
            Vector2 dir = new Vector2();

            if (kb.IsKeyDown(Keys.Up))
            {
                dir.Y -= 1;
            }
            if (kb.IsKeyDown(Keys.Right))
            {
                dir.X += 1;
                isRight = true;
            }
            if (kb.IsKeyDown(Keys.Down))
            {
                dir.Y += 1;
            }
            if (kb.IsKeyDown(Keys.Left))
            {
                dir.X -= 1;
                isRight = false;
            }

            if (dir.X < 0 && vel.X > -baseVel.X)
            {
                vel.X -= acceleration.X;
                if (vel.X < -baseVel.X)
                {
                    vel.X = -baseVel.X;
                }
            }
            else if (dir.X > 0 && vel.X < baseVel.X)
            {
                vel.X += acceleration.X;
                if (vel.X > baseVel.X)
                {
                    vel.X = baseVel.X;
                }
            }

            camera.loc.X += (int)vel.X;
            camera.loc.Y += (int)vel.Y;

            Console.WriteLine(vel.X);

            if (vel.X > -VelStop && vel.X < VelStop)
            {
                idleAnim.next();
            }
            else
            {
                walkAnim.next();
            }
        }

        public void draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            if (isRight)
            {
                if (vel.X > -VelStop && vel.X < VelStop)
                {
                    spriteBatch.Draw(idleAnim.getFrame(), loc, Color.White);
                }
                else
                {
                    spriteBatch.Draw(walkAnim.getFrame(), loc, Color.White);
                }
            }
            else
            {
                if (vel.X > -VelStop && vel.X < VelStop)
                {
                    spriteBatch.Draw(idleAnim.getFrame(), loc, null, Color.White, 0f, new Vector2(0, 0), SpriteEffects.FlipHorizontally, 1f);
                }
                else
                {
                    spriteBatch.Draw(walkAnim.getFrame(), loc, null, Color.White, 0f, new Vector2(0, 0), SpriteEffects.FlipHorizontally, 1f);
                }
            }
        }
    }
}
