using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace Paper_Down_Under
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Enemy bee;
        Animation beeAnim;
        Texture2D beeText;
        Dictionary<string, Tile> tileInterpret;
        List<Room> rooms;
        Room currRoom;
        Player player;
        const int TileLength = 64;
        Camera camera;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            graphics.PreferredBackBufferWidth = 1200;
            graphics.PreferredBackBufferHeight = 675;
            graphics.ApplyChanges();

            camera = new Camera(GraphicsDevice.Viewport.Bounds, GraphicsDevice.Viewport.Bounds);
            rooms = new List<Room>();
            tileInterpret = new Dictionary<string, Tile>();
            base.Initialize();
            IsMouseVisible = true;
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            beeText = this.Content.Load<Texture2D>("Sprites/Bee Sprite Sheet");
            readTileInterpreter(@"Content/Tiles/convert.txt");
            LoadEnemies();
            for (int i = 0; i < Int32.MaxValue; i++)
            {
                try
                {
                    readMap(@"Content/Maps/Map" + i + ".map");
                }
                catch (FileNotFoundException e)
                {
                    break;
                }
            }
            currRoom = rooms[0];

            Texture2D idle = Content.Load<Texture2D>("Sprites/Player Generic Idle");
            Texture2D walk = Content.Load<Texture2D>("Sprites/Player Generic Walk");
            player = new Player(new Animation(idle, GraphicsDevice, new Rectangle(0, 0, idle.Height, idle.Height), 10, 16),
                new Animation(walk, GraphicsDevice, new Rectangle(0, 0, walk.Height, walk.Height), 5, 13),
                new Rectangle(GraphicsDevice.Viewport.Bounds.Center.X - TileLength / 2, GraphicsDevice.Viewport.Bounds.Center.Y - TileLength / 2, TileLength, TileLength),
                camera, new Vector2(5, 5), new Vector2(.7f, .7f));
        }

        //will eventually turn into loading only the enemies & animations for the current area
        protected void LoadEnemies()
        {
            LoadAnimations();
            bee = new Enemy(60, 0, 95, 15, 5, "Enraged Bee", beeAnim, new Rectangle(500, 100, 200, 140), camera);
        }

        protected void LoadAnimations()
        {
            int[] beeImgs = new int[6];
            for (int i = 0; i < 6; i++)
            {
                beeImgs[i] = 2;
            }
            beeAnim = new Animation(beeText, GraphicsDevice, new Rectangle(0, 0, 200, 140), beeImgs);
        }

        private void readTileInterpreter(string path)
        {
            try
            {
                using (StreamReader reader = new StreamReader(path))
                {
                    while (!reader.EndOfStream)
                    {
                        string[] data = reader.ReadLine().Split(' ');
                        string[] size = data[data.Length - 1].Split('x');
                        int width = Convert.ToInt32(size[0]);
                        int height = Convert.ToInt32(size[1]);
                        if (data[1].Equals("none"))
                        {
                            tileInterpret.Add(data[0], new Tile(new Rectangle(0, 0, width * TileLength, height * TileLength), null, Tile.TileState.Passable, camera));
                        }
                        else
                        {
                            Texture2D img = Content.Load<Texture2D>("Tiles/Forest/" + data[1]);
                            switch (data[2])
                            {
                                case "solid":
                                    tileInterpret.Add(data[0], new Tile(new Rectangle(0, 0, width * TileLength, height * TileLength), img, Tile.TileState.Solid, camera));
                                    break;
                                case "passa":
                                    tileInterpret.Add(data[0], new Tile(new Rectangle(0, 0, width * TileLength, height * TileLength), img, Tile.TileState.Passable, camera));
                                    break;
                                case "fluid":
                                    tileInterpret.Add(data[0], new Tile(new Rectangle(0, 0, width * TileLength, height * TileLength), img, Tile.TileState.Fluid, camera));
                                    break;
                            }
                        }
                    }
                }
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine("The tile interpetation file could not be found:");
                Console.WriteLine(e.Message);
            }
        }

        /// <summary>
        /// Reads in the room specified by the file path.
        /// </summary>
        private void readMap(string path)
        {
            using (StreamReader reader = new StreamReader(path))
            {
                List<List<string>> mapData = new List<List<string>>();
                Texture2D background = Content.Load<Texture2D>("Backgrounds/" + reader.ReadLine());
                string[] dirsData = reader.ReadLine().Split(' ');
                int[] dirs = new int[dirsData.Length];
                for (int i = 0; i < dirsData.Length; i++)
                {
                    dirs[i] = Convert.ToInt32(dirsData[i]);
                }
                while (!reader.EndOfStream)
                {
                    string[] line = reader.ReadLine().Split(' ');
                    mapData.Add(new List<string>(line));
                }
                Tile[][] map = new Tile[mapData.Count][];
                for (int r = 0; r < mapData.Count; r++)
                {
                    map[r] = new Tile[mapData[r].Count];
                    for (int c = 0; c < mapData[r].Count - 1; c++)
                    {
                        Tile convTile = tileInterpret[mapData[r][c]];
                        map[r][c] = new Tile(new Rectangle(r * TileLength, c * TileLength, convTile._loc.Width, convTile._loc.Height), convTile._image, convTile._state, camera);
                    }
                }
                //int rowCount = map.Length;
                //int columnCount = map[0].Length;
                //Tile[][] transposed = new Tile[columnCount][];
                //for (int c = 0; c < columnCount; c++)
                //{
                //    transposed[c] = new Tile[rowCount];
                //    for (int r = 0; r < rowCount; r++)
                //    {
                //        transposed[c][r] = map[r][c];
                //    }
                //}
                rooms.Add(new Room(rooms.Count, dirs[0], dirs[1], dirs[2], dirs[3], background, map, camera));
            }
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            player.update(gameTime, currRoom);

            // TODO: Add your update logic here
            //bee.update();
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.White);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            currRoom.draw(gameTime, spriteBatch);
            player.draw(gameTime, spriteBatch);
            //if (bee.isAlive())
            //{
            //    bee.draw(gameTime, spriteBatch);
            //}
            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}