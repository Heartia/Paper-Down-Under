﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Paper_Down_Under
{
    class Room
    {
        private int num;
        private int up, right, down, left;
        private Texture2D background;
        private Tile[][] tileMap;
        private Camera camera;

        public Room(int _num, int _up, int _right, int _down, int _left, Texture2D _background, Tile[][] _tileMap, Camera _camera)
        {
            num = _num;
            up = _up;
            right = _right;
            down = _down;
            background = _background;
            tileMap = _tileMap;
            camera = _camera;
        }

        public void draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(background, camera.viewport, Color.White);
            foreach (Tile[] tiles in tileMap)
            {
                foreach (Tile tile in tiles)
                {
                    if (tile != null)
                    {
                        tile.draw(gameTime, spriteBatch, camera);
                    }
                }
            }
        }
    }
}
