﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace Paper_Down_Under
{
    class Player : GameObject
    {
        private Vector2 baseVel;
        private Vector2 acceleration;
        private KeyboardState kb;
        private Boolean isRight;
        private Boolean isCrouching;
        private Boolean isJumping;
        private Animation walkAnim;
        private Animation crouchAnim;
        private Animation jumpAnim;
        private Boolean canJump;
        const int TileLength = 64;

        private const float VelStop = 1.5f;
        private const int walkSpeed = 10;
        private const float decceleration = .3f;

        public Player(Animation _idleAnim, Animation _walkAnim, Animation _jumpAnim, Animation _crouchAnim, Rectangle _loc, Camera _camera, Vector2 _baseVel, Vector2 _acceleration) : base(_idleAnim, _loc, _camera)
        {
            baseVel = _baseVel;
            acceleration = _acceleration;
            kb = Keyboard.GetState();
            walkAnim = _walkAnim;
            jumpAnim = _jumpAnim;
            crouchAnim = _crouchAnim;
            isCrouching = false;
            isJumping = false;
        }

        public void update(GameTime gameTime, Room curr)
        {
            kb = Keyboard.GetState();
            Vector2 dir = new Vector2();

            if (canJump)
            {
                if (kb.IsKeyDown(Keys.Up))
                {
                    isJumping = true;
                    dir.Y -= 1;
                }
                else
                {
                    isJumping = false;
                    canJump = false;
                    
                }
            }
            
            if (kb.IsKeyDown(Keys.Right))
            {
                dir.X += 1;
                isRight = true;
            }
            //To be Added once Collisions are fixed
            if (kb.IsKeyDown(Keys.Down))
            {
                dir.Y += 1;
                //isCrouching = true;
            }
            else if (vel.Y == 0)
            {
                //isCrouching = false;
            }
            if (kb.IsKeyDown(Keys.Left))
            {
                dir.X -= 1;
                isRight = false;
            }

            if (dir.Y < 0)
            {
                vel.Y -= 2 * acceleration.Y;
                if (vel.Y < -(2 * baseVel.Y / 3))
                {
                    vel.Y = -(2 * baseVel.Y / 3);
                    canJump = false;
                }
            }
            if (dir.X < 0 && vel.X > -baseVel.X)
            {
                vel.X -= acceleration.X;
                if (vel.X < -baseVel.X)
                {
                    vel.X = -baseVel.X;
                }
            }
            else if (dir.X > 0 && vel.X < baseVel.X)
            {
                vel.X += acceleration.X;
                if (vel.X > baseVel.X)
                {
                    vel.X = baseVel.X;
                }
            }

            if (dir.X == 0)
            {
                if (vel.X > 0)
                {
                    vel.X -= decceleration;
                    if (vel.X < 0)
                    {
                        vel.X = 0;
                    }
                }
                else if (vel.X < 0)
                {
                    vel.X += decceleration;
                    if (vel.X > 0)
                    {
                        vel.X = 0;
                    }
                }
            }

            vel.Y += (acceleration.Y / 2);
            if (vel.Y > baseVel.Y)
            {
                vel.Y = baseVel.Y;
            }
            
            Rectangle oldLoc = camera.loc;
            camera.loc.X += (int)vel.X;
            camera.loc.Y += (int)vel.Y;

            Tile[][] map = curr.tileMap;

            int row = (int)Math.Round((float)camera.loc.Center.X / TileLength) - 1;
            int yrow = (int)Math.Round((float)(camera.loc.Center.X - TileLength / 2) / TileLength) - 1;
            int col = (int)Math.Round((float)camera.loc.Center.Y / TileLength);
            Console.WriteLine(row + " " + col + " : " + map.Length + " " + map[0].Length);

            if (yrow + 1 < map.Length && yrow + 1 >= 0 && col - 1 >= 0 && col - 1 < map[0].Length &&
                map[yrow + 1][col - 1] != null && (map[yrow + 1][col - 1]._state == Tile.TileState.Impassable ||
                map[yrow + 1][col - 1]._state == Tile.TileState.Platform))
            {
                if (vel.Y < 0)
                {
                    if (kb.IsKeyDown(Keys.Up))
                    {
                        vel.Y = 2 * acceleration.Y;
                    }
                    else
                    {
                        vel.Y = baseVel.Y / 10;
                    }
                    //camera.loc = oldLoc;
                }
            }

            if (yrow + 1 < map.Length && yrow + 1 >= 0 && col >= 0 && col < map[0].Length &&
                map[yrow + 1][col] != null && (map[yrow + 1][col]._state == Tile.TileState.Impassable ||
                map[yrow + 1][col]._state == Tile.TileState.Platform))
            {
                if (vel.Y > 0)
                {
                    vel.Y = -(vel.Y / 5);
                    canJump = true;
                    isJumping = false;
                    //camera.loc = oldLoc;
                }
 
            }
            else
            {
                if (row < map.Length && row >= 0 && col >= 0 && col < map[0].Length &&
                    map[row][col] != null && map[row][col]._state == Tile.TileState.Impassable)
                {
                    if (vel.X < 0)
                    {
                        vel.X = 0;
                        //camera.loc = oldLoc;
                    }
                }

                if (row + 1 < map.Length && row + 1 >= 0 && col >= 0 && col < map[0].Length &&
                    map[row + 1][col] != null && map[row + 1][col]._state == Tile.TileState.Impassable)
                {
                    if (vel.X > 0)
                    {
                        vel.X = 0;
                        //camera.loc = oldLoc;
                    }
                }
            }

            camera.loc.X += (int)vel.X;
            camera.loc.Y += (int)vel.Y;

            if (isJumping)
            {
                jumpAnim.next();
            }
            else
            {
                jumpAnim.last();
            }
            if (vel.X > -VelStop && vel.X < VelStop)
            {
                idleAnim.next();
                walkAnim.last();
            }
            else
            {
                walkAnim.imgTick = (int)Math.Abs(Math.Round(walkSpeed / (vel.X / 2)));
                walkAnim.next();
                idleAnim.last();
            }
        }

        public void draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            if (isRight)
            {
                if (isJumping)
                {
                    spriteBatch.Draw(jumpAnim.getFrame(), loc, Color.White);
                }
                else if (isCrouching)
                {
                    spriteBatch.Draw(crouchAnim.getFrame(), loc, Color.White);
                }
                else if (vel.X > -VelStop && vel.X < VelStop)
                {
                    spriteBatch.Draw(idleAnim.getFrame(), loc, Color.White);
                }
                else
                {
                    spriteBatch.Draw(walkAnim.getFrame(), loc, Color.White);
                }
            }
            else
            {
                if (isJumping)
                {
                    spriteBatch.Draw(jumpAnim.getFrame(), loc, null, Color.White, 0f, new Vector2(0, 0), SpriteEffects.FlipHorizontally, 1f);
                }
                else if (isCrouching)
                {
                    spriteBatch.Draw(crouchAnim.getFrame(), loc, null, Color.White, 0f, new Vector2(0, 0), SpriteEffects.FlipHorizontally, 1f);
                }
                else if (vel.X > -VelStop && vel.X < VelStop)
                {
                    spriteBatch.Draw(idleAnim.getFrame(), loc, null, Color.White, 0f, new Vector2(0, 0), SpriteEffects.FlipHorizontally, 1f);
                }
                else
                {
                    spriteBatch.Draw(walkAnim.getFrame(), loc, null, Color.White, 0f, new Vector2(0, 0), SpriteEffects.FlipHorizontally, 1f);
                }
            }
        }
    }
}
